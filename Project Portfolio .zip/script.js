// Dark / Light Toggle
const toggle = document.getElementById("theme-toggle");

toggle.addEventListener("click", () => {
  document.body.classList.toggle("light");
  toggle.textContent =
    document.body.classList.contains("light") ? "🌙" : "☀";
});

// Modal
function openModal(title) {
  document.getElementById("modal").style.display = "flex";
  document.getElementById("modal-title").innerText = title;
}

function closeModal() {
  document.getElementById("modal").style.display = "none";
}

// GSAP Reveal Animation
gsap.to(".reveal", {
  opacity: 1,
  y: 0,
  duration: 1,
  stagger: 0.2,
  ease: "power3.out"
});
// Prevent form reload
const form = document.getElementById("contact-form");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  alert("Message sent successfully 🚀");

  form.reset();
});